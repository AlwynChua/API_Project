const connect = require('./connect')

connect.deleteMany()
    .then(res=> {
    console.log("Success deleting all");
    });
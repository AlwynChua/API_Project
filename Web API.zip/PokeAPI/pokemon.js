const axios = require('axios');

const querystr = 'https://pokeapi.co/api/v2/pokemon/pikachu';

axios.get(querystr).then( (response) =>{
    console.log(response.data.abilities[0].ability);
    console.log(response.data.abilities[1].ability);

}
);
const connect = require('./connect')

connect.deleteOne({Abilities1: "blaze"})
    .then(res=> {
    console.log("Success deleting one");
    });
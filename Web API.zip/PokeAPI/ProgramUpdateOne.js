const connect = require('./connect')

connect.updateOne({Abilities1: "blaze"}, {Abilities1: "fireball"})
    .then(res=> {
    console.log("Success update one");
    });
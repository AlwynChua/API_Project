const mongoose = require('mongoose');

const db = "mongodb+srv://Eason:pokemon123@pokeapi.ggfvtro.mongodb.net/PokeAPI";

mongoose.connect(db).then(()=> {
console.log("Connected to database");
}
)

.catch(()=> {
console.log("Can't connect to database");
}

)

const cardSchema = new mongoose.Schema({
    Abilities1: {type: String},
    Abilities2: {type: String},
}
)

const connect = mongoose.model('Pokemon', cardSchema);

module.exports = connect;
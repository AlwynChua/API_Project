const axios = require('axios');
const connect = require('./connect')
 
const querystr = `https://pokeapi.co/api/v2/pokemon/charizard`;
 
axios.get(querystr).then( (response) =>{
        pokemonValue = new connect ({
        Abilities1:response.data.abilities[0].ability.name,
        Abilities2:response.data.abilities[1].ability.name,
        });
   
           
        pokemonValue.save().then(result=> {
        console.log("Success" + result);
        })
   
        .catch (error=> {
        console.log("Error" + error);
        }
   
        );
    });
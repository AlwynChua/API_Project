const connect = require('./connect');
const axios = require('axios');

const querystr = `https://gsi.fly.dev/characters/search?vision=Electro&weapon=Polearm`;
axios.get(querystr).then( (response) =>{
filmValue = new connect ({

id:response.data.results[0].id,
name:response.data.results[0].name,
rarity:response.data.results[0].rarity,
weapon:response.data.results[0].weapon,
vision:response.data.results[0].vision,
wiki_url:response.data.results[0].wiki_url,

});
filmValue.save().then(result=> {
console.log("Success" + result);
})
.catch (error=> {
console.log("Error" + error);
}
);
});

const mongoose = require('mongoose');
const db =
"mongodb+srv://ytmaxlim:pvwb4nYmdPb48T9I@genshin.gmeyxjz.mongodb.net/genshin"
mongoose.connect(db).then(()=> {
console.log("Connected to database");
}
)
.catch(()=> {
console.log("Can't connect to database");
}
)
const filmSchema = new mongoose.Schema({
id: { type: String},
name: { type: String},
rarity: { type: String},
weapon: { type: String},
vision: { type: String},
wiki_url: { type: String},
}
);
const Connect = mongoose.model('genshin', filmSchema);
module.exports = Connect;
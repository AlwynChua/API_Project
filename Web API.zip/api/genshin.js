const axios = require('axios');

const querystr = 'https://gsi.fly.dev/characters/search';

axios.get(querystr).then( (response) =>{
    console.log(response.data.results[0].id);
    console.log(response.data.results[0].name);
    console.log(response.data.results[0].rarity);
    console.log(response.data.results[0].weapon);
    console.log(response.data.results[0].vision);
    console.log(response.data.results[0].wiki_url);

}
);
const connect = require('./connect')

connect.updateOne({Name: "A Wingbeat of Giant Dragon"}, {Name: "Dark Magician"})
    .then(res=> {
    console.log("Success update one");
    });
const axios = require('axios');
const connect = require('./connect')
 
const querystr = `https://db.ygoprodeck.com/api/v7/cardinfo.php?fname=Dragon`;
 
axios.get(querystr).then( (response) =>{
        const index = 0;
        cardValue = new connect ({
        ID:response.data.data[index].id,
        Name:response.data.data[index].name,
        Type:response.data.data[index].type,
        FrameType:response.data.data[index].frameType,
        Description:response.data.data[index].desc,
        Attack:response.data.data[index].atk,
        Defense:response.data.data[index].def,
        Level:response.data.data[index].level,
        Race:response.data.data[index].race,
        Attribute:response.data.data[index].attribute,
        Archetype:response.data.data[index].archetype
        });
   
           
        cardValue.save().then(result=> {
        console.log("Success" + result);
        })
   
        .catch (error=> {
        console.log("Error" + error);
        }
   
        );
    });
const connect = require('./connect')

connect.deleteOne({Name: "Dark Magician"})
    .then(res=> {
    console.log("Success deleting one");
    });
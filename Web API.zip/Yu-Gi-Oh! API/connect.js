const mongoose = require('mongoose');

const db = "mongodb+srv://Alwyn:LtzaIAQDkkDTB8p6@cluster0.v77mtnz.mongodb.net/Yu-Gi-Yoh";

mongoose.connect(db).then(()=> {
console.log("Connected to database");
}
)

.catch(()=> {
console.log("Can't connect to database");
}

)

const cardSchema = new mongoose.Schema({
    ID: {type: String},
    Name: {type: String},
    Type: {type: String},
    FrameType: {type: String},
    Description: {type: String},
    Attack: {type: String},
    Defense: {type: String},
    Level: {type: String},
    Race: {type: String},
    Attribute: {type: String},
    Archetype: {type: String}
}
)

const connect = mongoose.model('Yu-Gi-Yoh', cardSchema);

module.exports = connect;